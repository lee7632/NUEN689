simpleFoam -postProcess -func writeCellCentres -latestTime

decomposePar
mpirun -n 8 simpleFoam -parallel
reconstructPar

#paraFoam

