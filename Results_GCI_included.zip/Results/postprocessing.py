# -*- coding: utf-8 -*-
"""
Jieun Lee 
A postprocessing engine to obtain LHS RESULTS 
"""
# import modules 
import os 
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.interpolate import interp1d
import statistics 


# directory path change
postprocessing_directory_path = os.getcwd() + "/Postprocessings/"
os.chdir(postprocessing_directory_path)

data = {}

for i in range(0, len(os.listdir())):
    os.chdir(postprocessing_directory_path + "LHS_" + str(i))
    # creating LHS dictionaries
    data['LHS_' + str(i)] = {}
    
    # getting turbulence kinetic energy for different x- locations
    # At050
    y_locs = []
    k_temp = [] 
    with open(r"At050_k.xy") as f:
        content = f.readlines()   
        data['LHS_' + str(i)]['At050'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
    data['LHS_' + str(i)]['At050']['y'] = y_locs
    data['LHS_' + str(i)]['At050']['k'] = k_temp
    # At150
    y_locs = []
    k_temp = [] 
    with open(r"At150_k.xy") as f:
        content = f.readlines()   
        data['LHS_' + str(i)]['At150'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
    data['LHS_' + str(i)]['At150']['y'] = y_locs
    data['LHS_' + str(i)]['At150']['k'] = k_temp
    # At250
    y_locs = []
    k_temp = [] 
    with open(r"At250_k.xy") as f:
        content = f.readlines()   
        data['LHS_' + str(i)]['At250'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
    data['LHS_' + str(i)]['At250']['y'] = y_locs
    data['LHS_' + str(i)]['At250']['k'] = k_temp
    # At350
    y_locs = []
    k_temp = [] 
    with open(r"At350_k.xy") as f:
        content = f.readlines()   
        data['LHS_' + str(i)]['At350'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
    data['LHS_' + str(i)]['At350']['y'] = y_locs
    data['LHS_' + str(i)]['At350']['k'] = k_temp
    # At450
    y_locs = []
    k_temp = [] 
    with open(r"At450_k.xy") as f:
        content = f.readlines()   
        data['LHS_' + str(i)]['At450'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
    data['LHS_' + str(i)]['At450']['y'] = y_locs
    data['LHS_' + str(i)]['At450']['k'] = k_temp

    # getting mean velocity profiles for different x- locations  
    # At050
    Ux_temp = []
    Uy_temp = []
    Uz_temp = []
    with open(r"At050_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
            Uy_temp.append(float(line.split()[2]))
            Uz_temp.append(float(line.split()[3]))
            
    data['LHS_' + str(i)]['At050']['Ux'] = Ux_temp
    data['LHS_' + str(i)]['At050']['Uy'] = Uy_temp 
    data['LHS_' + str(i)]['At050']['Uz'] = Uz_temp 
    # At150
    Ux_temp = []
    Uy_temp = []
    Uz_temp = []
    with open(r"At150_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
            Uy_temp.append(float(line.split()[2]))
            Uz_temp.append(float(line.split()[3]))
            
    data['LHS_' + str(i)]['At150']['Ux'] = Ux_temp
    data['LHS_' + str(i)]['At150']['Uy'] = Uy_temp 
    data['LHS_' + str(i)]['At150']['Uz'] = Uz_temp 
    # At250
    Ux_temp = []
    Uy_temp = []
    Uz_temp = []
    with open(r"At250_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
            Uy_temp.append(float(line.split()[2]))
            Uz_temp.append(float(line.split()[3]))
            
    data['LHS_' + str(i)]['At250']['Ux'] = Ux_temp
    data['LHS_' + str(i)]['At250']['Uy'] = Uy_temp 
    data['LHS_' + str(i)]['At250']['Uz'] = Uz_temp 
    # At350
    Ux_temp = []
    Uy_temp = []
    Uz_temp = []
    with open(r"At350_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
            Uy_temp.append(float(line.split()[2]))
            Uz_temp.append(float(line.split()[3]))
            
    data['LHS_' + str(i)]['At350']['Ux'] = Ux_temp
    data['LHS_' + str(i)]['At350']['Uy'] = Uy_temp 
    data['LHS_' + str(i)]['At350']['Uz'] = Uz_temp 
    # At450
    Ux_temp = []
    Uy_temp = []
    Uz_temp = []
    with open(r"At450_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
            Uy_temp.append(float(line.split()[2]))
            Uz_temp.append(float(line.split()[3]))
            
    data['LHS_' + str(i)]['At450']['Ux'] = Ux_temp
    data['LHS_' + str(i)]['At450']['Uy'] = Uy_temp 
    data['LHS_' + str(i)]['At450']['Uz'] = Uz_temp 

####### Reference Data ##################3
    
os.chdir(postprocessing_directory_path + '/../PIV-dr0u10_N337')
test = {}

VARIABLES = ["x", "y", "Vx", "U_x95", "Vy", "U_y95", "RMSVx", "RMSxLOW", "RMSxUP", "RMSVy", "RMSyLOW", "RMSyUP", "tauxy", "tauxyLOW", "tauxyUP", "k", "kLOW", "kUP"]
with open("X050_PIV_dr0_u10.dat", mode='r') as f_handle:
    test['At050'] = pd.read_csv(f_handle, sep="\t", skiprows=5, names=VARIABLES, header=None, usecols=np.arange(0,18,1))
with open("X150_PIV_dr0_u10.dat", mode='r') as f_handle:
    test['At150'] = pd.read_csv(f_handle, sep="\t", skiprows=5, names=VARIABLES, header=None, usecols=np.arange(0,18,1))
with open("X250_PIV_dr0_u10.dat", mode='r') as f_handle:
    test['At250'] = pd.read_csv(f_handle, sep="\t", skiprows=5, names=VARIABLES, header=None, usecols=np.arange(0,18,1))
with open("X350_PIV_dr0_u10.dat", mode='r') as f_handle:
    test['At350'] = pd.read_csv(f_handle, sep="\t", skiprows=5, names=VARIABLES, header=None, usecols=np.arange(0,18,1))
with open("X450_PIV_dr0_u10.dat", mode='r') as f_handle:
    test['At450'] = pd.read_csv(f_handle, sep="\t", skiprows=5, names=VARIABLES, header=None, usecols=np.arange(0,18,1))

 
f = {}
for i in range(0, 19):
    f['LHS_' + str(i)] = {}
    
    #050 data 
    f['LHS_' + str(i)]['At050'] = {}
    f['LHS_' + str(i)]['At050']['Ux'] = {}
    f['LHS_' + str(i)]['At050']['k'] = {}
    
    func = interp1d(data['LHS_' + str(i)]['At050']['y'], data['LHS_' + str(i)]['At050']['Ux'])
    func2 = interp1d(data['LHS_' + str(i)]['At050']['y'], data['LHS_' + str(i)]['At050']['k'])
    
    f['LHS_' + str(i)]['At050']['Ux'] = func(test['At050']["y"].values)
    f['LHS_' + str(i)]['At050']['k'] = func2(test['At050']["y"].values)
    
    #150 data 
    f['LHS_' + str(i)]['At150'] = {}
    f['LHS_' + str(i)]['At150']['Ux'] = {}
    f['LHS_' + str(i)]['At150']['k'] = {}
    
    func = interp1d(data['LHS_' + str(i)]['At150']['y'], data['LHS_' + str(i)]['At150']['Ux'])
    func2 = interp1d(data['LHS_' + str(i)]['At150']['y'], data['LHS_' + str(i)]['At150']['k'])
    
    f['LHS_' + str(i)]['At150']['Ux'] = func(test['At150']["y"].values)
    f['LHS_' + str(i)]['At150']['k'] = func2(test['At150']["y"].values)
    
    #250 data 
    f['LHS_' + str(i)]['At250'] = {}
    f['LHS_' + str(i)]['At250']['Ux'] = {}
    f['LHS_' + str(i)]['At250']['k'] = {}
    
    func = interp1d(data['LHS_' + str(i)]['At250']['y'], data['LHS_' + str(i)]['At250']['Ux'])
    func2 = interp1d(data['LHS_' + str(i)]['At250']['y'], data['LHS_' + str(i)]['At250']['k'])
    
    f['LHS_' + str(i)]['At250']['Ux'] = func(test['At250']["y"].values)
    f['LHS_' + str(i)]['At250']['k'] = func2(test['At250']["y"].values)
    
    #350 data 
    f['LHS_' + str(i)]['At350'] = {}
    f['LHS_' + str(i)]['At350']['Ux'] = {}
    f['LHS_' + str(i)]['At350']['k'] = {}
    
    func = interp1d(data['LHS_' + str(i)]['At350']['y'], data['LHS_' + str(i)]['At350']['Ux'])
    func2 = interp1d(data['LHS_' + str(i)]['At350']['y'], data['LHS_' + str(i)]['At350']['k'])
    
    f['LHS_' + str(i)]['At350']['Ux'] = func(test['At350']["y"].values)
    f['LHS_' + str(i)]['At350']['k'] = func2(test['At350']["y"].values)
    
    #450 data 
    f['LHS_' + str(i)]['At450'] = {}
    f['LHS_' + str(i)]['At450']['Ux'] = {}
    f['LHS_' + str(i)]['At450']['k'] = {}
    
    func = interp1d(data['LHS_' + str(i)]['At450']['y'], data['LHS_' + str(i)]['At450']['Ux'])
    func2 = interp1d(data['LHS_' + str(i)]['At450']['y'], data['LHS_' + str(i)]['At450']['k'])
    
    f['LHS_' + str(i)]['At450']['Ux'] = func(test['At450']["y"].values)
    f['LHS_' + str(i)]['At450']['k'] = func2(test['At450']["y"].values)
 
  
# Data extraction of u and k for uncertainty and mean values 
info = {}
info['At050'] = {}
info['At050']['Ux'] = {}
info['At050']['k'] = {}

info['At150'] = {}
info['At150']['Ux'] = {}
info['At150']['k'] = {}

info['At250'] = {}
info['At250']['Ux'] = {}
info['At250']['k'] = {}

info['At350'] = {}
info['At350']['Ux'] = {}
info['At350']['k'] = {}

info['At450'] = {}
info['At450']['Ux'] = {}
info['At450']['k'] = {}

# 050 data
k = 0
while k < 18:
    temp1 = []
    temp2 = []
    
    for i in range(0,19):
        temp1.append(float(f['LHS_' + str(i)]['At050']['Ux'][k]))
        temp2.append(float(f['LHS_' + str(i)]['At050']['k'][k]))  

    info['At050']['Ux'][str(k)] = temp1
    info['At050']['k'][str(k)] = temp2
    
    k = k + 1
# 150 data 
k = 0
while k < 18:
    temp1 = []
    temp2 = []
    
    for i in range(0,19):
        temp1.append(float(f['LHS_' + str(i)]['At150']['Ux'][k]))
        temp2.append(float(f['LHS_' + str(i)]['At150']['k'][k]))  

    info['At150']['Ux'][str(k)] = temp1
    info['At150']['k'][str(k)] = temp2
    
    k = k + 1
# 250 data 
k = 0
while k < 18:
    temp1 = []
    temp2 = []
    
    for i in range(0,19):
        temp1.append(float(f['LHS_' + str(i)]['At250']['Ux'][k]))
        temp2.append(float(f['LHS_' + str(i)]['At250']['k'][k]))  

    info['At250']['Ux'][str(k)] = temp1
    info['At250']['k'][str(k)] = temp2
    
    k = k + 1  
# 350 data 
k = 0
while k < 18:
    temp1 = []
    temp2 = []
    
    for i in range(0,19):
        temp1.append(float(f['LHS_' + str(i)]['At350']['Ux'][k]))
        temp2.append(float(f['LHS_' + str(i)]['At350']['k'][k]))  

    info['At350']['Ux'][str(k)] = temp1
    info['At350']['k'][str(k)] = temp2
    
    k = k + 1 
# 450 data 
k = 0
while k < 18:
    temp1 = []
    temp2 = []
    
    for i in range(0,19):
        temp1.append(float(f['LHS_' + str(i)]['At450']['Ux'][k]))
        temp2.append(float(f['LHS_' + str(i)]['At450']['k'][k]))  

    info['At450']['Ux'][str(k)] = temp1
    info['At450']['k'][str(k)] = temp2
    
    k = k + 1 
    
### statistics, postprocessing of LHS results 
sample = {}
sample['At050'] = {}
sample['At050']['Ux'] = {}
sample['At050']['Ux']['std_Ux'] = {}
sample['At050']['Ux']['mean_Ux'] = {}
sample['At050']['k'] = {}
sample['At050']['k']['std_k'] = {}
sample['At050']['k']['mean_k'] = {}

sample['At150'] = {}
sample['At150']['Ux'] = {}
sample['At150']['Ux']['std_Ux'] = {}
sample['At150']['Ux']['mean_Ux'] = {}
sample['At150']['k'] = {}
sample['At150']['k']['std_k'] = {}
sample['At150']['k']['mean_k'] = {}

sample['At250'] = {}
sample['At250']['Ux'] = {}
sample['At250']['Ux']['std_Ux'] = {}
sample['At250']['Ux']['mean_Ux'] = {}
sample['At250']['k'] = {}
sample['At250']['k']['std_k'] = {}
sample['At250']['k']['mean_k'] = {}

sample['At350'] = {}
sample['At350']['Ux'] = {}
sample['At350']['Ux']['std_Ux'] = {}
sample['At350']['Ux']['mean_Ux'] = {}
sample['At350']['k'] = {}
sample['At350']['k']['std_k'] = {}
sample['At350']['k']['mean_k'] = {}

sample['At450'] = {}
sample['At450']['Ux'] = {}
sample['At450']['Ux']['std_Ux'] = {}
sample['At450']['Ux']['mean_Ux'] = {}
sample['At450']['k'] = {}
sample['At450']['k']['std_k'] = {}
sample['At450']['k']['mean_k'] = {}

k = 0
while k < 18:
    sample['At050']['Ux']['std_Ux'][str(k)] = statistics.stdev(info['At050']['Ux'][str(k)])
    sample['At050']['Ux']['mean_Ux'][str(k)] = statistics.mean(info['At050']['Ux'][str(k)]) 
    sample['At050']['k']['std_k'][str(k)] = statistics.stdev(info['At050']['k'][str(k)])
    sample['At050']['k']['mean_k'][str(k)] = statistics.mean(info['At050']['k'][str(k)])  
    
    sample['At150']['Ux']['std_Ux'][str(k)] = statistics.stdev(info['At150']['Ux'][str(k)])
    sample['At150']['Ux']['mean_Ux'][str(k)] = statistics.mean(info['At150']['Ux'][str(k)]) 
    sample['At150']['k']['std_k'][str(k)] = statistics.stdev(info['At150']['k'][str(k)])
    sample['At150']['k']['mean_k'][str(k)] = statistics.mean(info['At150']['k'][str(k)]) 

    sample['At250']['Ux']['std_Ux'][str(k)] = statistics.stdev(info['At250']['Ux'][str(k)])
    sample['At250']['Ux']['mean_Ux'][str(k)] = statistics.mean(info['At250']['Ux'][str(k)]) 
    sample['At250']['k']['std_k'][str(k)] = statistics.stdev(info['At250']['k'][str(k)])
    sample['At250']['k']['mean_k'][str(k)] = statistics.mean(info['At250']['k'][str(k)]) 
    
    sample['At350']['Ux']['std_Ux'][str(k)] = statistics.stdev(info['At350']['Ux'][str(k)])
    sample['At350']['Ux']['mean_Ux'][str(k)] = statistics.mean(info['At350']['Ux'][str(k)]) 
    sample['At350']['k']['std_k'][str(k)] = statistics.stdev(info['At350']['k'][str(k)])
    sample['At350']['k']['mean_k'][str(k)] = statistics.mean(info['At350']['k'][str(k)])   
    
    sample['At450']['Ux']['std_Ux'][str(k)] = statistics.stdev(info['At450']['Ux'][str(k)])
    sample['At450']['Ux']['mean_Ux'][str(k)] = statistics.mean(info['At450']['Ux'][str(k)]) 
    sample['At450']['k']['std_k'][str(k)] = statistics.stdev(info['At450']['k'][str(k)])
    sample['At450']['k']['mean_k'][str(k)] = statistics.mean(info['At450']['k'][str(k)]) 
    
    k = k + 1 

#for i in range(len(sample['At050']['Ux']['std_Ux'])):
#    print(sample['At050']['Ux']['std_Ux'][str(i)]/sample['At050']['Ux']['mean_Ux'][str(i)]*100)
#################################### GCI analysis 

def GCI(path, test): 
    os.chdir(path)
    base = {}
    
    # getting turbulence kinetic energy for different x- locations
    # At050
    y_locs = []
    k_temp = [] 
    
    with open(r"At050_k.xy") as f:
        content = f.readlines()   
        base['At050'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
        base['At050']['y'] = y_locs
        base['At050']['k'] = k_temp
    # At150
    y_locs = []
    k_temp = [] 
    
    with open(r"At150_k.xy") as f:
        content = f.readlines()   
        base['At150'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
        base['At150']['y'] = y_locs
        base['At150']['k'] = k_temp
    # At250
    y_locs = []
    k_temp = [] 
    
    with open(r"At250_k.xy") as f:
        content = f.readlines()   
        base['At250'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
        base['At250']['y'] = y_locs
        base['At250']['k'] = k_temp
    # At350
    y_locs = []
    k_temp = [] 
    
    with open(r"At350_k.xy") as f:
        content = f.readlines()   
        base['At350'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
        base['At350']['y'] = y_locs
        base['At350']['k'] = k_temp 
    # A450
    y_locs = [] 
    k_temp = [] 
    
    with open(r"At450_k.xy") as f:
        content = f.readlines()   
        base['At450'] = {}
        for line in content:
            y_locs.append(float(line.split()[0])*1000)
            k_temp.append(float(line.split()[1]))
        base['At450']['y'] = y_locs
        base['At450']['k'] = k_temp    

    # getting mean velocity profiles for different x- locations  
    # At050
    Ux_temp = []
    with open(r"At050_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
    base['At050']['Ux'] = Ux_temp
    
    # At150
    Ux_temp = []
    with open(r"At150_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
    base['At150']['Ux'] = Ux_temp
    
    # At250 
    Ux_temp = []
    with open(r"At250_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
    base['At250']['Ux'] = Ux_temp
    
    # At350 
    Ux_temp = []
    with open(r"At350_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
    base['At350']['Ux'] = Ux_temp
    
    # At450 
    Ux_temp = []
    with open(r"At450_U.xy") as f:
        content = f.readlines()   
        for line in content:
            Ux_temp.append(float(line.split()[1]))
    base['At450']['Ux'] = Ux_temp
    
    f = {}
    #050 data 
    f['At050'] = {}
    f['At050']['Ux'] = {}
    f['At050']['k'] = {}
    
    func = interp1d(base['At050']['y'], base['At050']['Ux'])
    func2 = interp1d(base['At050']['y'], base['At050']['k'])
    
    f['At050']['Ux'] = func(test['At050']["y"].values)
    f['At050']['k'] = func2(test['At050']["y"].values)
    
    #150 data 
    f['At150'] = {}
    f['At150']['Ux'] = {}
    f['At150']['k'] = {}
    
    func = interp1d(base['At150']['y'], base['At150']['Ux'])
    func2 = interp1d(base['At150']['y'], base['At150']['k'])
    
    f['At150']['Ux'] = func(test['At150']["y"].values)
    f['At150']['k'] = func2(test['At150']["y"].values)
    
    #250 data 
    f['At250'] = {}
    f['At250']['Ux'] = {}
    f['At250']['k'] = {}
    
    func = interp1d(base['At250']['y'], base['At250']['Ux'])
    func2 = interp1d(base['At250']['y'], base['At250']['k'])
    
    f['At250']['Ux'] = func(test['At250']["y"].values)
    f['At250']['k'] = func2(test['At250']["y"].values)
    
    #350 data 
    f['At350'] = {}
    f['At350']['Ux'] = {}
    f['At350']['k'] = {}
    
    func = interp1d(base['At350']['y'], base['At350']['Ux'])
    func2 = interp1d(base['At350']['y'], base['At350']['k'])
    
    f['At350']['Ux'] = func(test['At350']["y"].values)
    f['At350']['k'] = func2(test['At350']["y"].values)
    
    #450 data 
    f['At450'] = {}
    f['At450']['Ux'] = {}
    f['At450']['k'] = {}
    
    func = interp1d(base['At450']['y'], base['At450']['Ux'])
    func2 = interp1d(base['At450']['y'], base['At450']['k'])
    
    f['At450']['Ux'] = func(test['At450']["y"].values)
    f['At450']['k'] = func2(test['At450']["y"].values)
    
    return (f)

refined_results = GCI(postprocessing_directory_path + "../BaseResults",test)
medium_results = GCI(postprocessing_directory_path + "../MediumMesh", test)
coarse_results = GCI(postprocessing_directory_path + "../CoarseMesh", test)


## p-observed calculation
p = {}
p['At050'] = {}
p['At150'] = {}
p['At250'] = {}
p['At350'] = {}
p['At450'] = {}

gci = {}
gci['At050'] = {} 
gci['At150'] = {}
gci['At250']= {}
gci['At350']= {}
gci['At450']= {}

# for Ux
p['At050']['Ux'] =  np.log(abs((max(coarse_results['At050']['Ux']) - max(medium_results['At050']['Ux']))/(max((medium_results['At050']['Ux']) - max(refined_results['At050']['Ux'])))))/np.log(5/3)
p['At150']['Ux'] =  np.log(abs((max(coarse_results['At150']['Ux']) - max(medium_results['At150']['Ux']))/(max((medium_results['At150']['Ux']) - max(refined_results['At150']['Ux'])))))/np.log(5/3)
p['At250']['Ux'] =  np.log(abs((max(coarse_results['At250']['Ux']) - max(medium_results['At250']['Ux']))/(max((medium_results['At250']['Ux']) - max(refined_results['At250']['Ux'])))))/np.log(5/3)
p['At350']['Ux'] =  np.log(abs((max(coarse_results['At350']['Ux']) - max(medium_results['At350']['Ux']))/(max((medium_results['At350']['Ux']) - max(refined_results['At350']['Ux'])))))/np.log(5/3)
p['At450']['Ux'] =  np.log(abs((max(coarse_results['At450']['Ux']) - max(medium_results['At450']['Ux']))/(max((medium_results['At450']['Ux']) - max(refined_results['At450']['Ux'])))))/np.log(5/3)   

# for k 
p['At050']['k'] =  np.log(abs((coarse_results['At050']['k'][8] - medium_results['At050']['k'][8])/(medium_results['At050']['k'][8] - refined_results['At050']['k'][8])))/np.log(5/3)
p['At150']['k'] =  np.log(abs((coarse_results['At150']['k'][8] - medium_results['At150']['k'][8])/(medium_results['At150']['k'][8] - refined_results['At150']['k'][8])))/np.log(5/3)
p['At250']['k'] =  np.log(abs((coarse_results['At250']['k'][8] - medium_results['At250']['k'][8])/(medium_results['At250']['k'][8] - refined_results['At250']['k'][8])))/np.log(5/3)
p['At350']['k'] =  np.log(abs((coarse_results['At350']['k'][8] - medium_results['At350']['k'][8])/(medium_results['At350']['k'][8] - refined_results['At350']['k'][8])))/np.log(5/3)
p['At450']['k'] =  np.log(abs((coarse_results['At450']['k'][8] - medium_results['At450']['k'][8])/(medium_results['At450']['k'][8] - refined_results['At450']['k'][8])))/np.log(5/3)   
"""
print(p['At050']['Ux'])
print(p['At150']['Ux'])
print(p['At250']['Ux'])
print(p['At350']['Ux'])
print(p['At450']['Ux'])
print('\n')
print(p['At050']['k'])
print(p['At150']['k'])
print(p['At250']['k'])
print(p['At350']['k'])
print(p['At450']['k'])
print('\n')   
"""
# for Ux 
gci['At050']['Ux'] = 3/((5/3)**p['At050']['Ux']-1) * abs(max(medium_results['At050']['Ux']) - max(refined_results['At050']['Ux']))  
gci['At150']['Ux'] = 3/((5/3)**p['At150']['Ux']-1) * abs(max(medium_results['At150']['Ux']) - max(refined_results['At150']['Ux']))  
gci['At250']['Ux'] = 3/((5/3)**p['At250']['Ux']-1) * abs(max(medium_results['At250']['Ux']) - max(refined_results['At250']['Ux']))  
gci['At350']['Ux'] = 3/((5/3)**p['At350']['Ux']-1) * abs(max(medium_results['At350']['Ux']) - max(refined_results['At350']['Ux']))  
gci['At450']['Ux'] = 3/((5/3)**p['At450']['Ux']-1) * abs(max(medium_results['At450']['Ux']) - max(refined_results['At450']['Ux']))  

# for k 
gci['At050']['k'] = 3/((5/3)**p['At050']['k']-1) * abs(medium_results['At050']['k'][8] - refined_results['At050']['k'][8])  
gci['At150']['k'] = 3/((5/3)**p['At150']['k']-1) * abs(medium_results['At150']['k'][8] - refined_results['At150']['k'][8])  
gci['At250']['k'] = 3/((5/3)**p['At250']['k']-1) * abs(medium_results['At250']['k'][8] - refined_results['At250']['k'][8])  
gci['At350']['k'] = 3/((5/3)**p['At350']['k']-1) * abs(medium_results['At350']['k'][8] - refined_results['At350']['k'][8])  
gci['At450']['k'] = 3/((5/3)**p['At450']['k']-1) * abs(medium_results['At450']['k'][8] - refined_results['At450']['k'][8])  
"""
print(gci['At050']['Ux'])
print(gci['At150']['Ux'])
print(gci['At250']['Ux'])
print(gci['At350']['Ux'])
print(gci['At450']['Ux'])
print('\n')
print(gci['At050']['k'])
print(gci['At150']['k'])
print(gci['At250']['k'])
print(gci['At350']['k'])
print(gci['At450']['k'])

print('\n')
"""

### Relative unceratinty (in percent) ###
# for u
mean_050_u = (max(coarse_results['At050']['Ux']) + max(medium_results['At050']['Ux']) + max(refined_results['At050']['Ux']))/3
mean_150_u = (max(coarse_results['At150']['Ux']) + max(medium_results['At150']['Ux']) + max(refined_results['At150']['Ux']))/3
mean_250_u = (max(coarse_results['At250']['Ux']) + max(medium_results['At250']['Ux']) + max(refined_results['At250']['Ux']))/3
mean_350_u = (max(coarse_results['At350']['Ux']) + max(medium_results['At350']['Ux']) + max(refined_results['At350']['Ux']))/3
mean_450_u = (max(coarse_results['At450']['Ux']) + max(medium_results['At450']['Ux']) + max(refined_results['At450']['Ux']))/3

# for k
mean_050_k = (coarse_results['At050']['k'][8] + medium_results['At050']['k'][8] + refined_results['At050']['k'][8])/3
mean_150_k = (coarse_results['At150']['k'][8] + medium_results['At150']['k'][8] + refined_results['At150']['k'][8])/3
mean_250_k = (coarse_results['At250']['k'][8] + medium_results['At250']['k'][8] + refined_results['At250']['k'][8])/3
mean_350_k = (coarse_results['At350']['k'][8] + medium_results['At350']['k'][8] + refined_results['At350']['k'][8])/3
mean_450_k = (coarse_results['At450']['k'][8] + medium_results['At450']['k'][8] + refined_results['At450']['k'][8])/3
"""
print(mean_050_u)
print(mean_150_u)
print(mean_250_u)
print(mean_350_u)
print(mean_450_u)
print('\n')
print(mean_050_k)
print(mean_150_k)
print(mean_250_k)
print(mean_350_k)
print(mean_450_k)
print('\n')
"""

gci['At050']['Ux'] = gci['At050']['Ux'] /mean_050_u 
gci['At150']['Ux'] = gci['At150']['Ux'] /mean_150_u 
gci['At250']['Ux'] = gci['At250']['Ux'] /mean_250_u 
gci['At350']['Ux'] = gci['At350']['Ux'] /mean_350_u 
gci['At450']['Ux'] = gci['At450']['Ux'] /mean_450_u 

gci['At050']['k'] = gci['At050']['k'] /mean_050_k 
gci['At150']['k'] = gci['At150']['k'] /mean_150_k 
gci['At250']['k'] = gci['At250']['k'] /mean_250_k 
gci['At350']['k'] = gci['At350']['k'] /mean_350_k 
gci['At450']['k'] = gci['At450']['k'] /mean_450_k 

print(gci['At050']['Ux'])
print(gci['At150']['Ux'])
print(gci['At250']['Ux'])
print(gci['At350']['Ux'])
print(gci['At450']['Ux'])
print('\n')
print(gci['At050']['k'])
print(gci['At150']['k'])
print(gci['At250']['k'])
print(gci['At350']['k'])
print(gci['At450']['k'])

## 

os.chdir(postprocessing_directory_path +"/../")
# 050
file = open("UQ_x_0.05.data", "w+")
file.write("x\t\t" + "y\t" + "U\t\t" + "U-DU\t\t" +"U+DU\t\t" + "K\t\t" + "K-KU\t\t" + "K+KU\n")
for i in range(0, 18):
    file.write("0.05" + 
               "\t" + str(test['At050']["y"][i]/1000) + 
               "\t" + str(refined_results['At050']['Ux'][i]) + 
               "\t" + str(refined_results['At050']['Ux'][i] - 2*(sample['At050']['Ux']['std_Ux'][str(i)]+ refined_results['At050']['Ux'][i]*gci['At050']['Ux'])) + 
               "\t" + str(refined_results['At050']['Ux'][i] + 2*(sample['At050']['Ux']['std_Ux'][str(i)]+ refined_results['At050']['Ux'][i]*gci['At050']['Ux'])) + 
               "\t" + str(refined_results['At050']['k'][i]) +
               "\t" + str(refined_results['At050']['k'][i] - 2*(sample['At050']['k']['std_k'][str(i)]+ refined_results['At050']['k'][i]*gci['At050']['k'])) + 
               "\t" + str(refined_results['At050']['k'][i] + 2*(sample['At050']['k']['std_k'][str(i)]+ refined_results['At050']['k'][i]*gci['At050']['k'])) + 
               "\n")
file.close()
# 150
file = open("UQ_x_0.15.data", "w+")
file.write("x\t\t" + "y\t" + "U\t\t" + "U-DU\t\t" +"U+DU\t\t" + "K\t\t" + "K-KU\t\t" + "K+KU\n")
for i in range(0, 18):
    file.write("0.15" + 
               "\t" + str(test['At150']["y"][i]/1000) + 
               "\t" + str(refined_results['At150']['Ux'][i]) + 
               "\t" + str(refined_results['At150']['Ux'][i] - 2*(sample['At150']['Ux']['std_Ux'][str(i)]+ refined_results['At150']['Ux'][i]*gci['At150']['Ux'])) + 
               "\t" + str(refined_results['At150']['Ux'][i] + 2*(sample['At150']['Ux']['std_Ux'][str(i)]+ refined_results['At150']['Ux'][i]*gci['At150']['Ux'])) + 
               "\t" + str(refined_results['At150']['k'][i]) +
               "\t" + str(refined_results['At150']['k'][i] - 2*(sample['At150']['k']['std_k'][str(i)]+ refined_results['At150']['k'][i]*gci['At150']['k'])) + 
               "\t" + str(refined_results['At150']['k'][i] + 2*(sample['At150']['k']['std_k'][str(i)]+ refined_results['At150']['k'][i]*gci['At150']['k'])) + 
               "\n")
file.close()
# 250
file = open("UQ_x_0.25.data", "w+")
file.write("x\t\t" + "y\t" + "U\t\t" + "U-DU\t\t" +"U+DU\t\t" + "K\t\t" + "K-KU\t\t" + "K+KU\n")
for i in range(0, 18):
    file.write("0.25" + 
               "\t" + str(test['At250']["y"][i]/1000) + 
               "\t" + str(refined_results['At250']['Ux'][i]) + 
               "\t" + str(refined_results['At250']['Ux'][i] - 2*(sample['At250']['Ux']['std_Ux'][str(i)]+ refined_results['At250']['Ux'][i]*gci['At250']['Ux'])) + 
               "\t" + str(refined_results['At250']['Ux'][i] + 2*(sample['At250']['Ux']['std_Ux'][str(i)]+ refined_results['At250']['Ux'][i]*gci['At250']['Ux'])) + 
               "\t" + str(refined_results['At250']['k'][i]) +
               "\t" + str(refined_results['At250']['k'][i] - 2*(sample['At250']['k']['std_k'][str(i)]+ refined_results['At250']['k'][i]*gci['At250']['k'])) + 
               "\t" + str(refined_results['At250']['k'][i] + 2*(sample['At250']['k']['std_k'][str(i)]+ refined_results['At250']['k'][i]*gci['At250']['k'])) + 
               "\n")
file.close()
# 350
file = open("UQ_x_0.35.data", "w+")
file.write("x\t\t" + "y\t" + "U\t\t" + "U-DU\t\t" +"U+DU\t\t" + "K\t\t" + "K-KU\t\t" + "K+KU\n")
for i in range(0, 18):
    file.write("0.35" + 
               "\t" + str(test['At350']["y"][i]/1000) + 
               "\t" + str(refined_results['At350']['Ux'][i]) + 
               "\t" + str(refined_results['At350']['Ux'][i] -2*(sample['At350']['Ux']['std_Ux'][str(i)]+ refined_results['At350']['Ux'][i]*gci['At350']['Ux'])) + 
               "\t" + str(refined_results['At350']['Ux'][i] + 2*(sample['At350']['Ux']['std_Ux'][str(i)]+ refined_results['At350']['Ux'][i]*gci['At350']['Ux'])) + 
               "\t" + str(refined_results['At350']['k'][i]) +
               "\t" + str(refined_results['At350']['k'][i] - 2*(sample['At350']['k']['std_k'][str(i)]+ refined_results['At350']['k'][i]*gci['At350']['k'])) + 
               "\t" + str(refined_results['At350']['k'][i] + 2*(sample['At350']['k']['std_k'][str(i)]+ refined_results['At350']['k'][i]*gci['At350']['k'])) + 
               "\n")
file.close()
# 450
file = open("UQ_x_0.45.data", "w+")
file.write("x\t\t" + "y\t" + "U\t\t" + "U-DU\t\t" +"U+DU\t\t" + "K\t\t" + "K-KU\t\t" + "K+KU\n")
for i in range(0, 18):
    file.write("0.45" + 
               "\t" + str(test['At450']["y"][i]/1000) + 
               "\t" + str(refined_results['At450']['Ux'][i]) + 
               "\t" + str(refined_results['At450']['Ux'][i] -2*(sample['At450']['Ux']['std_Ux'][str(i)]+ refined_results['At450']['Ux'][i]*gci['At450']['Ux'])) + 
               "\t" + str(refined_results['At450']['Ux'][i] + -2*(sample['At450']['Ux']['std_Ux'][str(i)]+ refined_results['At450']['Ux'][i]*gci['At450']['Ux'])) + 
               "\t" + str(refined_results['At450']['k'][i]) +
               "\t" + str(refined_results['At450']['k'][i] - 2*(sample['At450']['k']['std_k'][str(i)]+ refined_results['At450']['k'][i]*gci['At450']['k'])) + 
               "\t" + str(refined_results['At450']['k'][i] + 2*(sample['At450']['k']['std_k'][str(i)]+ refined_results['At450']['k'][i]*gci['At450']['k'])) + 
               "\n")
file.close()


file = open("Information.data", "w+")
file.write("Item\t" + "Short description\t" + "Information\n"
           + "1\t" + "Code used\t" + "OpenFOAM7\n" 
           + "2\t" + "Control Volumes\t" + "1150000\n" 
           + "3\t" + "Spatial differencing scheme\t" + "2nd-Bounded gauss linear upwind unlimited\n"
           + "4\t" + "Convergence criteria\t" + "10e-5\n"
           + "5\t" + "Turbulence model\t" + "k-omega SST\n"
           + "6\t" + "Wall treatment\t" + "wall-resolved\n"
           + "7\t" + "CPU time\t" + "1725\n"
           + "8\t" + "Total number of simluations\t" + "23\n"
           + "9\t" + "UQ method\t" + "Latin hypercube sampling, GCI\n"
           + "10\t" + "Mapping method of the experimental inlet boundary condition\t" 
           + "Linear interpolation\n") 
           
file.close()




#### 
    #plt.plot(f['LHS_0']['At050']['k'], test['At050']["y"].values)  
#plt.plot(test['At050']["k"].values, test['At050']["y"].values) 

#plt.plot(f['LHS_0']['At150']['k'], test['At150']["y"].values)  
#plt.plot(test['At150']["k"].values, test['At150']["y"].values) 

#plt.plot(f['LHS_0']['At250']['k'], test['At250']["y"].values)  
#plt.plot(test['At250']["k"].values, test['At250']["y"].values) 

#plt.plot(f['LHS_0']['At350']['k'], test['At350']["y"].values)  
#plt.plot(test['At350']["k"].values, test['At350']["y"].values) 

#plt.plot(f['LHS_0']['At450']['k'], test['At450']["y"].values)  
#plt.plot(test['At450']["k"].values, test['At450']["y"].values)

